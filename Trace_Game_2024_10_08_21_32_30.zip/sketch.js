function setup() {
  createCanvas(600, 600);
  background(200);

  let yellowPreset = color(255, 255, 180)
  let greenPreset = color(180, 255, 180)
  let bluePreset = color(180, 180, 255)
  
  let selectedColor = random([yellowPreset, greenPreset, bluePreset])
  let selectedShape = random([0, 1, 2])
  
  if(selectedShape == 0)
    {
      setupCircle(selectedColor)
    }
  if (selectedShape == 1)
    {
      setupTriangle(selectedColor)
    }
  if (selectedShape == 2)
    {
      setupSquare(selectedColor)
    }
}

function setupCircle(selectedPreset)
{
  stroke(selectedPreset)
  strokeWeight(25)
  circle(300, 300, 300);
}

function setupTriangle(selectedPreset)
{
  stroke(selectedPreset)
  strokeWeight(25)
  triangle(150, 450, 300, 150, 450, 450);
}

function setupSquare(selectedPreset)
{
  stroke(selectedPreset)
  strokeWeight(25)
  square(150, 150, 300);
}

function draw() {
  let b = color(0, 0, 0);
  stroke(b);
  strokeWeight(6);

  if (mouseIsPressed) {
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
}
