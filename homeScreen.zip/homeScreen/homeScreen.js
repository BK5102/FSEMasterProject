

function setup() {

  createCanvas(1500, 900);


}

function draw() {

  
}


function navigateSignUp(){
    

}

function navigateSignIn(){
  


}



